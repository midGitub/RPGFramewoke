GameManager = {};
function GameManager.hello()
	return "我是旧版本"
end