﻿
public enum LuaEnumType {
    AAA = 1,
    BBB = 2,
    CCC = 3,
    DDD = 4
}
