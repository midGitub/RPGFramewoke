因为按钮单击例子设计NGUI/UGUI视图层关联，所以压缩，请根据自身使用的UI进行整理，
更多信息访问BBS站：http://http://bbs.ulua.org/