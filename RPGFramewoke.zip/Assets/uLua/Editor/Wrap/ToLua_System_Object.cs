﻿using UnityEngine;
using System.Collections;

public class ToLua_System_Object 
{
    [OnlyGCAttribute]
    public static void Destroy(object obj)
    {
    }
}
