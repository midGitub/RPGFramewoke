﻿using UnityEngine;
using System.Collections;

public class Server{
    public static string RemoteAssetBundleUrl = "file:///D:/Res/";
}
